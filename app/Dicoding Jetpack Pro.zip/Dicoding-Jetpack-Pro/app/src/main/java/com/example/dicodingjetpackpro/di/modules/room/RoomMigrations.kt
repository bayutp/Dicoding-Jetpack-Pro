package com.example.dicodingjetpackpro.di.modules.room

object RoomMigrations